/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#ifndef _MISSION3_H_
#define _MISSION3_H_
void canAnagram(char str[]);
void mission3();
#endif