/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#ifndef _MISSION5_H_
#define _MISSION5_H_
void mission5();
void loadCastleBoard(char mat[][/*Complete..*/], int rows, int cols);
int getMinLength(char mat[][/*Complete..*/], int r, int c, int goalR, int goalC, int n);
#endif