/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#ifndef _MISSION4_H_
#define _MISSION4_H_
void mission4();
void runGame(int n, int m, long c, char board[][/*Complete..*/]);
void loadBoard(char mat[][/*Complete..*/], int rows, int cols);
#endif