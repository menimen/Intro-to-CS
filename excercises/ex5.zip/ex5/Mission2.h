/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#ifndef _MISSION2_H_
#define _MISSION2_H_
void mission2();
int sweetCookies(int cookies[], int n, int K);
#endif