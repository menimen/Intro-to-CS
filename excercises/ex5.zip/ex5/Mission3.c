/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#include "Mission3.h"

/************************************************************************
* function name: isSemiSimilar 											*
* The Input: str - string containing a-z letters 						*
* The output: None														*
* The Function operation: The function prints if str can be changed to 	*
							be a polindrom								*
*************************************************************************/
void canAnagram(char str[])
{
	// Complete..
}

/************************************************************************
 Fill comment
*************************************************************************/
void mission3()
{
	char str[/*Complete..*/];
	printf("Please enter the string:\n");
	scanf("%s", str);				// input the str
	CanAnagram(str);
}