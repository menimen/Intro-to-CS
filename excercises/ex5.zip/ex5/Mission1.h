/******************************************
*Student name: name and family name
*Student ID:XXXX
*Submit Info:XXXX
*Exercise name: exXXXX
******************************************/ 

#ifndef _MISSION1_H_
#define _MISSION1_H_
void mission1();
int isSemiSimilar(char target[], char source[]);
#endif